ALTER TABLE `contact` 
ADD COLUMN `email` VARCHAR(45) NULL AFTER `phone_number`;