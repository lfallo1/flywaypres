UPDATE `yearly_contract` SET `role`='Offense' WHERE `id`='9830';
UPDATE `yearly_contract` SET `role`='Defense' WHERE `id`='12368';
UPDATE `yearly_contract` SET `role`='Defense' WHERE `id`='13161';
