UPDATE `team` SET `primary_color`='FB4F14', `secondary_color`='000000' WHERE `id`='7';
UPDATE `team` SET `primary_color`='870619', `secondary_color`='000000' WHERE `id`='29';
