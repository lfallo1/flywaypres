UPDATE `yearly_contract` SET `status`='null' WHERE `id`='12157';

INSERT INTO `contract_status` (`name`) VALUES ('Other');