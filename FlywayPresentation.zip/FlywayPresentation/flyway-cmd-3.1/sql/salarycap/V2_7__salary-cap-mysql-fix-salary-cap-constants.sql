INSERT INTO `salary_cap_constants` (`year`, `team`, `carryover_incentive_adjustments`, `adjusted_cap`, `salary_cap`) VALUES ('2018', '20', '0', '170000000', '170000000');

UPDATE `salary_cap_constants` SET `year`='2017', `salary_cap`='160000000' WHERE `id`='97';